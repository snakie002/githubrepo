---
title: ""
date: "YYYY-MM-DD"
categories: <!-- Only 3 --> 
  - ""
  - ""
  - ""
tags:  <! -- Only 5 -->
  - ""
  - ""
  - ""
coverImage: "post_assets/thumbnail.jpg"


---

<!-- Embed -->

<iframe width="782" height="440" src="https://www.youtube.com/embed/W0rGCnuyOhI" 
  title="YouTube video player" frameborder="0" allow="accelerometer; autoplay;
  clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
  referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


<!-- Context -->

大家好，又是我Snakie 何師傅。  

[原文連結](https:)：  

![](post_assets/.png)
<!-- Subtitle1 -->
##

![](post_assets/.png)  
<!-- Subtitle2 -->
##
  
![](post_assets/.png)  
<!-- Subtitle3 -->
##
  
![](post_assets/.png)  
<!-- Subtitle4 -->
##

![](post_assets/.png)  
<!-- Subtitle5 -->
##

![](post_assets/.png)  
<!-- Subtitle6 -->
##

![](post_assets/.png)  
<!-- Subtitle7 -->
##

![](post_assets/.png)  
<!-- Subtitle8 -->
##
  


